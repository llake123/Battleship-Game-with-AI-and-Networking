package com.company;

import com.sun.deploy.util.SessionState;

import javax.swing.*;
import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;

import static java.lang.Integer.parseInt;

/**
 * Created by Lane on 11/28/2016.
 */
public class BattleShipGame {

    String comMode = "";
    int comPortNumber = -1;
    String sComName = "";
    Board board = new Board();
    Packet packet= new Packet();
    Boolean winLoss = false;
    Date date = new Date();
    String out = "";

    BattleShipGame(String[] args) throws IOException, InterruptedException {

        this.setComMode(args[0]);
        this.setComName(args[1]);
        this.setComPort(args[2]);
        if(comMode.equalsIgnoreCase("SERVER")) {
            serverType();
        } else if (comMode.equalsIgnoreCase("CLIENT")) {
            clientType();
        }
    }



    private void setComMode(String s) {
        if(s.equalsIgnoreCase("SERVER")){
            comMode = "SERVER";
        }
        if(s.equalsIgnoreCase("CLIENT")){
            comMode = "CLIENT";
        }
        if(s.equalsIgnoreCase("TEST")){
            comMode = "TEST";
        }
    }

    private void setComName(String s) {
        sComName = s;
    }

    private void setComPort(String s) throws IOException {
        comPortNumber = Integer.parseInt(s);

    }

    private void clientType() throws InterruptedException, FileNotFoundException, UnsupportedEncodingException {

        JFrame frame = new JFrame("Battleship - Server");
        frame.add(board.getGui());
        frame.setLocationByPlatform(true);
        frame.setMinimumSize(frame.getSize());
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(900, 900));
        frame.setMinimumSize(new Dimension(900, 900));
        frame.setLocation(50, 50);
        frame.pack();
        frame.setVisible(true);
        ClientSocket client = null;

        try {
            client = new ClientSocket(sComName, comPortNumber);
            client.create();
            PrintWriter writer = new PrintWriter("LogFile.txt", "UTF-8");
            out = date.toString() + " Client is playing";
            writer.println(out);
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        packet.fillOpponentOcean();

        client.sendMessage(packet.createFirstPacket());
        do{
            packet.decodePacket(client.recieveMessage());
            board.checkHit(packet);
            if(packet.hitOrMiss.equals("L") || packet.shotResult.equals("L")){
                winLoss = true;
                client.sendMessage(packet.createPacket());
                PrintWriter writer = new PrintWriter("Config.txt", "UTF-8");
                out = date.toString() + " Win";
                writer.println(out);
                System.exit(1);
                client.close();
            }
            else client.sendMessage(packet.createPacket());
        }while(winLoss == false);
        client.close();
    }

    private void serverType() throws InterruptedException, FileNotFoundException, UnsupportedEncodingException {

        JFrame frame = new JFrame("Battleship - Server");
        frame.add(board.getGui());
        frame.setLocationByPlatform(true);
        frame.setMinimumSize(frame.getSize());
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(900, 900));
        frame.setMinimumSize(new Dimension(900, 900));
        frame.setLocation(50, 50);
        frame.pack();
        frame.setVisible(true);
        SvrSocket client = null;


        try {
            //client = new ClientSocket("localhost", 13000);
            client = new SvrSocket(comPortNumber);
            client.create();
            PrintWriter writer = new PrintWriter("LogFile.txt", "UTF-8");
            out = date.toString() + " Server is playing";
            writer.println("Server is playing");
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        packet.fillOpponentOcean();

        do{
            packet.decodePacket(client.recieveMessage());
            board.checkHit(packet);
            if(packet.hitOrMiss.equals("L") ||  packet.shotResult.equals("L")){
                winLoss = true;
                client.sendMessage(packet.createPacket());
                PrintWriter writer = new PrintWriter("Config.txt", "UTF-8");
                out = date.toString() + " Win";
                writer.println(out);

                client.close();
                System.exit(1);

            }
            else client.sendMessage(packet.createPacket());
        }while(winLoss == false);
        client.close();
    }



}
