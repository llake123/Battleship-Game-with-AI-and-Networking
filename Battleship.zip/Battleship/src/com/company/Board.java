package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Properties;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 * Created by Lane on 11/29/2016.
 */
public class Board {

    //Variables for placing ships
    Packet packet = new Packet();
    private final int SHIP_COUNT = 5;
    private String orientation;
    private String ship;
    private int xShip;
    private int yShip;
    private int shipSize;
    private int hullPoints;

    //Variables for setting the board
    private final JPanel board = new JPanel(new BorderLayout(4,4));
    private JButton[][] coordColor = new JButton[100][100];
    private JPanel c1Board;
    private final JLabel content = new JLabel("Player 1 Board");
    JToolBar tool = new JToolBar();
    Insets Margin = new Insets(0,0,0,0);
    int blocks = 100;
    int space = 1000;
    ImageIcon icon = new ImageIcon(new BufferedImage(space, space, BufferedImage.TYPE_INT_ARGB));

    Board() throws FileNotFoundException, UnsupportedEncodingException {
        try {
            initializeGui();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public final void initializeGui() throws FileNotFoundException {

        tool.setFloatable(false);
        board.add(tool, BorderLayout.PAGE_START);
        tool.add(content);
        c1Board = new JPanel(new GridLayout(0, 100));
        c1Board.setBorder(new LineBorder(Color.BLACK));
        board.add(c1Board);


        for (int i = 1; i < coordColor.length; i++) {
            for (int j = 0; j < coordColor[i].length; j++) {
                JButton b = new JButton();
                b.setMargin(Margin);
                b.setIcon(icon);
                if ((j % 2 == 1 && i % 2 == 1)
                        //) {
                        || (j % 2 == 0 && i % 2 == 0)) {
                    b.setBackground(Color.BLUE);
                } else {
                    b.setBackground(Color.BLUE);
                }
                coordColor[j][i] = b;
            }
        }
        for (int i = 1; i < blocks; i++) {
            for (int j = 0; j < blocks; j++) {
                c1Board.add(coordColor[j][i]);
            }
        }
        try {
            readShips();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public final JComponent getGui() {
        return board;
    }

    public void readShips() throws IOException {
        try{
            PrintWriter writer = new PrintWriter("Config.txt", "UTF-8");
            writer.println("AirCarrier,20,40,H,Cruiser,68,20,V,MotorBoat,14,5,H,Destroyer,80,80,V,BattleShip,50,67,V,");
            writer.close();
        } catch (IOException e) {
        }
        Scanner read = new Scanner(new File("Config.txt"));
        //Scanner read = new Scanner(new File("C:\\Users\\Lane\\IdeaProjects\\Battleship\\src\\com\\company\\Config"));
        read.useDelimiter(",");
        for(int i = 0; i< SHIP_COUNT; i++){
            ship = read.next();
            ship.toUpperCase();
            xShip = Integer.parseInt(read.next());
            yShip = Integer.parseInt(read.next());
            orientation = read.next();
            if(ship.equalsIgnoreCase("AIRCARRIER")){
                shipSize = 8;
                hullPoints +=8;
            }
            else if(ship.equalsIgnoreCase("CRUISER")){
                shipSize = 4;
                hullPoints +=4;
            }
            else if(ship.equalsIgnoreCase("MOTORBOAT")){
                shipSize = 3;
                hullPoints +=3;
            }
            else if(ship.equalsIgnoreCase("BATTLESHIP")){
                shipSize = 5;
                hullPoints +=5;
            }
            else if(ship.equalsIgnoreCase("DESTROYER")){
                shipSize = 6;
                hullPoints +=6;
            }
            setShips();
        }

        //find coord of ships and send to setShips with Orientation
    }

    public void setShips() {
        if(orientation.equals("H")){
            for (int i = xShip; i < xShip + shipSize; i++ ){
                coordColor[i][yShip].setBackground(Color.RED);
            }
        }
        else if(orientation.equals("V")){
            for (int i = yShip; i < yShip+shipSize; i++){
                coordColor[xShip][i].setBackground(Color.RED);
            }
        }
    }


    public void checkHit(Packet packet){
        int xCoord = packet.xCheck;
        int yCoord = packet.yCheck;
        if(coordColor[xCoord][yCoord].getBackground()== Color.BLUE||coordColor[xCoord][yCoord].getBackground()==Color.WHITE ) {
            coordColor[xCoord][yCoord].setBackground(Color.WHITE);
            packet.setHitOrMiss("M");
        }
        else if(coordColor[xCoord][yCoord].getBackground() == Color.YELLOW){
            coordColor[xCoord][yCoord].setBackground(Color.YELLOW);
            packet.setHitOrMiss("H");
        }
        else if(coordColor[xCoord][yCoord].getBackground() == Color.RED){
            coordColor[xCoord][yCoord].setBackground(Color.YELLOW);
            hullPoints--;
            if(hullPoints == 0) {
                packet.setHitOrMiss("L");
                JOptionPane.showMessageDialog(null, "YOU LOSE" , "", JOptionPane.INFORMATION_MESSAGE);
            }
            else
                packet.setHitOrMiss("H");

        }
    }
}

