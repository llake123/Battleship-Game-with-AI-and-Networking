package com.company;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Created by Lane on 11/29/2016.
 */

class ClientSocket {

    Socket socket;
    ObjectOutputStream objOut;
    ObjectInputStream objIn;
    String comName;
    String message;
    int portNumber;

    ClientSocket(String comName, int portNumber) {
        this.comName = comName;
        this.portNumber = portNumber;
        System.out.print("Waiting for server...");
    }

    public void create() throws IOException {
        socket = new Socket (comName, portNumber);
        objOut = new ObjectOutputStream(socket.getOutputStream());
        objIn = new ObjectInputStream(socket.getInputStream());
    }

    public void sendMessage(String message){
        try {
            objOut.writeObject(message);
            objOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String recieveMessage(){
        try {
            this.message = (String) objIn.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return message;
    }
    public void close(){
        System.exit(1);
    }
}
