package com.company;

import java.io.IOException;

public class Main{

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     * SHOUTOUT TO EMILY COX!!! Helped me with my front end (setting up my board.)
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        BattleShipGame g = null;
        String[] test = {"client", "localhost", "13000"};
        g = new BattleShipGame(test);


    }

}
