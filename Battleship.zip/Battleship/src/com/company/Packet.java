package com.company;

import javafx.util.Pair;

import javax.swing.*;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * Created by Lane on 11/29/2016.
 */
public class Packet {

    private String messageRecieved;
    private String[] splitMessage;
    public String packet;
    public String hitOrMiss="";
    String shotResult;
    private int[][] shotsFired = new int[100][100];
    private int x;
    private int y;
    public int xCheck;
    public int yCheck;
    private int Low = 0;
    private int High = 100;
    private int shotCount = 0;
    Date date = new Date();
    String out = "";
    PrintWriter writer;


    boolean destroyMode = false;
    int xFirstHit;
    int yFirstHit;

    int xLastHit;
    int yLastHit;

    Pair<Integer, Integer> vectorLEFT = new Pair(-1, 0);
    Pair<Integer, Integer> vectorUP = new Pair(0, -1);
    Pair<Integer, Integer> vectorRIGHT = new Pair(1, 0);
    Pair<Integer, Integer> vectorDOWN = new Pair(0, 1);

    //down or right

    boolean left = false;
    boolean up = false;
    boolean right = false;
    boolean down = false;

    Packet () throws FileNotFoundException, UnsupportedEncodingException {
        writer = new PrintWriter("LogFile.txt", "UTF-8");
    }

    public void fillOpponentOcean() {
        for(int i = 0; i < 100; i++){
            for(int j = 0; j < 100; j++){
                shotsFired[i][j]=0;
            }
        }
    }

    void setHitOrMiss(String hitOrMiss){
        //the hit or miss is done in board e
        this.hitOrMiss = hitOrMiss;
    }


    //SEARCH (enter in count to stop infinite)
    void createCoord(){

        if(destroyMode == true){
            destroyCoord();
        }
        else if(destroyMode == false) {
            x = randomNG();
            y = randomNG();
            checkShot(x,y);
        }
        //checkShot(x,y);
    }


    private void checkShot(int x, int y) {
        if(shotsFired[x][y]==0){
            shotsFired[x][y] = 1;
        }
        else if(shotsFired[x][y]==1 && shotCount < 15000 && destroyMode == false) createCoord();
    }


    //DESTROY
    void destroyCoord(){
        if(left == true){
            x = xLastHit+ vectorLEFT.getKey();
            y = yLastHit+ vectorLEFT.getValue();
        }
        else if(up == true){
            x = xLastHit+ vectorUP.getKey();
            y = yLastHit+ vectorUP.getValue();
        }
        else if(left == false && right == true){
            x = xLastHit+ vectorRIGHT.getKey();
            y = yLastHit+ vectorRIGHT.getValue();
        }
        else if(up == false && down == true){
            x = xLastHit+ vectorDOWN.getKey();
            y = yLastHit+ vectorDOWN.getValue();
        }
        else if(right == false && down == false){
            destroyMode = false;
        }
    }



    private int randomNG(){
        Random r = new Random();
        return r.nextInt(High-Low) + Low;
    }

    String createFirstPacket() throws FileNotFoundException, UnsupportedEncodingException {
        createCoord();
        packet = ("M" + "," + Integer.toString(x) + "," + Integer.toString(y));
        PrintWriter writer = new PrintWriter("LogFile.txt", "UTF-8");
        out = date.toString() + packet;
        writer.println(out);
        writer.close();
        return packet;
    }

    String createPacket(){
        createCoord();
        packet = ("" + hitOrMiss + "," + Integer.toString(x) + "," + Integer.toString(y));
        xLastHit = x;
        yLastHit = y;
        return packet;
    }

    public void decodePacket(String message) throws InterruptedException {
        messageRecieved = message;
        splitMessage = messageRecieved.split(",");
        setShotResult(splitMessage[0]);
        //Thread.sleep(100);
        if(shotResult.equalsIgnoreCase("H") && destroyMode == false) {
            xFirstHit = x;
            yFirstHit = y;
            destroyMode = true;
            left = true;
            up = true;
            right = true;
            down = true;
        }
        else if(shotResult.equalsIgnoreCase("M") && destroyMode == true){
            if(left == true){
                left = false;

                xLastHit = xFirstHit;
                yLastHit = yFirstHit;
            }
            else if(up == true){
                up = false;
                xLastHit = xFirstHit;
                yLastHit = yFirstHit;
            }
            else if(right == true){
                right = false;
                xLastHit = xFirstHit;
                yLastHit = yFirstHit;
            }
            else if(down == true){
                down = false;
            }
            else if(left == false && up == false && right == false && down == false){
                destroyMode = false;
            }
        }
        else if(shotResult.equalsIgnoreCase("L")){
            //  System.out.print("you win!");
            JOptionPane.showMessageDialog(null, "YOU WIN" , "", JOptionPane.INFORMATION_MESSAGE);

        }

        this.xCheck = Integer.parseInt(splitMessage[1]);
        this.yCheck = Integer.parseInt(splitMessage[2]);
        if(xCheck == 0){
            xCheck = 0;
        }
        else if(xCheck>100){
            xCheck = 100;
        }
        if(yCheck == 0){
            yCheck = 1;
        }
        else if(yCheck > 100){
            yCheck = 100;
        }

    }

    private void setShotResult(String shotResult) {
        this.shotResult = shotResult;
    }
}
