package com.company;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by Lane on 11/28/2016.
 */
public class StartUp {

    int gameMode = -2;
    int portNumber = -1;
    String comName = "";

    public StartUp(int iGameMode, String sComName, int comPortNumber) throws IOException {

        this.gameMode = iGameMode;
        this.comName = sComName;
        this.portNumber = comPortNumber;
    }

    private void humanStartUp() {

    }

    private ClientSocket clientStartUp() throws IOException {
        ClientSocket client =  new ClientSocket(comName, portNumber);
        return client;
    }

    private SvrSocket serverStartUp() throws IOException {
        SvrSocket serverSocket = new SvrSocket(portNumber);
        return serverSocket;
    }
}
