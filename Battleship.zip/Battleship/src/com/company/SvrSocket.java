package com.company;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by Lane on 11/28/2016.
 */
public class SvrSocket {

    ServerSocket serverSocket;
    Socket socket;
    ObjectOutputStream objOut;
    ObjectInputStream objIn;
    String comName;
    String message;
    int portNumber;

    public SvrSocket(int portNumber) {

        this.portNumber = portNumber;

    }
    public void create() throws IOException {
        serverSocket = new ServerSocket(portNumber);
        socket = serverSocket.accept();
        objOut = new ObjectOutputStream(socket.getOutputStream());
        objIn = new ObjectInputStream(socket.getInputStream());
    }
    public void sendMessage(String message){
        try {
            objOut.writeObject(message);
            objOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String recieveMessage(){
        try {
            this.message = (String) objIn.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return message;
    }
    public void close(){
        System.exit(1);
    }
}
